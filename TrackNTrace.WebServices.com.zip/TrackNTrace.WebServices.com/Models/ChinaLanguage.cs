﻿namespace TrackNTrace.WebServices.com.Models
{
    public class ChinaLanguage
    {
        public string SchemaLocation { get; set; }
        public string PackType { get; set; }
        public string PackUnit { get; set; }
        public string ProductName { get; set; }
        public string Strength { get; set; }
        public string LineManager { get; set; }
        public string PackageSpec { get; set; }
        public string ProductLine { get; set; }
  
    }
}
